%% Calibration and errors

close all;
clear;
%% Read Excel file
% Set to 1 to save plots to .png
save_fig = 0;
folder = 'C:\Users\Rohan\OneDrive - Vrije Universiteit Brussel\Master Thesis\Camera\Observations\';
filename = 'Calibration';
filename2 = 'True Calibration Wavelengths';
data = readtable(strcat(folder,filename));
calib_data = readtable(strcat(folder,filename2));

% Change index to select other spectra
index = 1;

% sg_title('Wavelength mapping');
title_str1 = ' Raw Spectra Neon lamp';
title_str2 = ' Saturation';
title_str3 = ' Filtered spectra';
title_str4 = ' Detected Peaks';

%% Select data index

i = index;
averaging = table2array(data(1,6*i-4));
frame_rate = table2array(data(1,6*i-3));
exposure = table2array(data(2,6*i-4));
gain_dB = table2array(data(2,6*i-3));
pixels_x = table2array(data(3,6*i-4));
pixels_y = table2array(data(3,6*i-3));

width_x = table2array(data(4,6*i-3));
width_y = table2array(data(5,6*i-3));

pixels = table2array(data(9:end,6*i-5));
spectra_pixels = table2array(data(9:end,6*i-4));

int_level = table2array(data(9:end,6*i-3));
int_distribution = table2array(data(9:end,6*i-2));

calib_wave_list = table2array(calib_data(:,2));
%% Detect peaks
% For peaks detection
min_peak_drop = 8;

% 1D median filter - Order: default:10 (if several peaks - set to total #peaks) 
median_filter_int = medfilt1(spectra_pixels,5);

[yval_filter,xpos_filter]=findpeaks(median_filter_int,pixels,'MinPeakProminence',min_peak_drop);


%% Calibration points and wavelengths
calib_waves = [flipud(xpos_filter) calib_wave_list(1:19)];
calib_waves = calib_waves(1:3:end,:);
figure;
plot(calib_waves(:,1),'-ob','MarkerSize',5,'LineWidth',2);hold on;
plot(calib_waves(:,2),'-or','MarkerSize',5,'LineWidth',2);
title('Calibration peaks','fontweight','bold','fontsize',16);
legend('Pixel value','Wavelength');
xlabel('Calibration peak #','fontweight','bold','fontsize',14);

if save_fig == 1
    saveas(gcf,fullfile(strcat(folder,filename,'nonlinearity.png')));
end

%% Polynomial Fit
error = zeros(6,1);
lambda_poly = zeros(length(pixels),6);
% fit_order = 1;
for fit_order = 1:5
    position = calib_waves(:,1); 
    calc_wave_calibs = calib_waves(:,2); 
    poly = polyfit(position,calc_wave_calibs,fit_order);
    lambda_poly(:,fit_order) = polyval(poly, pixels);
% end
% [x,y] = findpeaks(flipud(spectra_pixels),flipud(lambda_poly(:,1)));

    [yval_poly,xpos_poly]=findpeaks(flipud(median_filter_int),flipud(lambda_poly(:,fit_order)),'MinPeakProminence',min_peak_drop);
    error(fit_order) = rms(xpos_poly - calib_wave_list(1:19));
end

%% Plot Errors by polynomial order

figure;
plot(error(1:5),'-ok','MarkerSize',5,'LineWidth',2);
% ylim([0 Inf]);
title('Quality of polynomial fit','fontweight','bold','fontsize',16);
xlabel('Fit Order','fontweight','bold','fontsize',14);
ylabel('RMS Error [nm]','fontweight','bold','fontsize',14);

if save_fig == 1
    saveas(gcf,fullfile(strcat(folder,filename,'fitorder.png')));
end
