%% Process spectra - Just Laser
%% Plot spectrum - Empty Cuvette
% Read files and plot spectrum 
close all;
clear;
%% Read Excel file containing pixel-spectrum data
% Set save_fig to 1 for saving the plot into an image
save_fig = 0;
% Change the folder name to wherever the Excel file is placed
folder = 'C:\Users\Rohan\OneDrive - Vrije Universiteit Brussel\Master Thesis\FL Measurements\';
filename = 'Empty Cuvette';

data = readtable(strcat(folder,filename));
%% Get data into variables
pixels = table2array(data(3:end,1));
dark = 0*table2array(data(3:end,1));
V12 = table2array(data(3:end,2));
V54 = table2array(data(3:end,5));
V96 = table2array(data(3:end,8));
V138 = table2array(data(3:end,15));
V170 = table2array(data(3:end,20));

%% Wavelength mapping with coefficients
linear_formula = [-0.0515146415977297	668.080250784035];
offset = 4;
wavelengths = polyval(linear_formula,pixels);
%% Plot normalized
figure(1);
% plot(wavelengths, dark(:,1));
hold on;
% for i = 1:8
i = 1;    
plot(wavelengths, normalize(medfilt1(V12(:,i)-dark(:,i),5),'range'),'-','LineWidth',2);
plot(wavelengths, normalize(medfilt1(V54(:,i)-dark(:,i),5),'range'),'-','LineWidth',2);
plot(wavelengths, normalize(medfilt1(V96(:,i)-dark(:,i),5),'range'),'-','LineWidth',2);
plot(wavelengths, normalize(medfilt1(V138(:,i)-dark(:,i),5),'range'),'-','LineWidth',2);
plot(wavelengths, normalize(medfilt1(V170(:,i)-dark(:,i),5),'range'),'-','LineWidth',2);
xlabel('Wavelength [nm]','fontweight','bold','fontsize',14);
ylabel('Normalized Intensity Level [a.u.]','fontweight','bold','fontsize',14);
xlim([450 675]);
% xlim([275 1100]);
ylim([0 Inf])
title('Empty Cuvette - Laser','fontweight','bold','fontsize',16);
legend('12mW','54mW','96mW','138mW','170mW','Location','NorthEast');


if save_fig == 1
    saveas(gcf,fullfile(strcat(folder,filename,'Laserline.png')));
end

%% Plot normalized
figure(2);
% plot(wavelengths, dark(:,1));
hold on;
% for i = 1:8
i = 1;    
plot(wavelengths, medfilt1(V12(:,i)-dark(:,i),5),'-','LineWidth',2);
plot(wavelengths, medfilt1(V54(:,i)-dark(:,i),5),'-','LineWidth',2);
plot(wavelengths, medfilt1(V96(:,i)-dark(:,i),5),'-','LineWidth',2);
plot(wavelengths, medfilt1(V138(:,i)-dark(:,i),5),'-','LineWidth',2);
plot(wavelengths, medfilt1(V170(:,i)-dark(:,i),5),'-','LineWidth',2);
xlabel('Wavelength [nm]','fontweight','bold','fontsize',14);
ylabel('Intensity Level [a.u.]','fontweight','bold','fontsize',14);
xlim([450 675]);
title('Empty Cuvette - Laser','fontweight','bold','fontsize',16);
legend('12mW','54mW','96mW','138mW','170mW','Location','NorthEast');


if save_fig == 1
    saveas(gcf,fullfile(strcat(folder,filename,'LaserLinenorm.png')));
end
